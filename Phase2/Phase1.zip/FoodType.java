public class FoodType {    
    public static String foodType(String foodType) {
        if(foodType.equals("SeaFood"))
            return "SeaFood";
        if(foodType.equals("FastFood"))
            return "FastFood";
        if(foodType.equals("Drinks"))
            return "Drinks";
        if(foodType.equals("FruitVegetable"))
            return "FruitVegetable";
        if(foodType.equals("SweetCandy"))
            return "SweetCandy";
        if(foodType.equals("Dessert"))
            return "Dessert";
        if(foodType.equals("CoffeeShop"))
            return "CoffeeShop";
        if(foodType.equals("IranianFood"))
            return "IranianFood";
        if(foodType.equals("ItalianFood"))
            return "ItalianFood";
        if(foodType.equals("ChineseFood"))
            return "ChineseFood";
        if(foodType.equals("SuperMarket"))
            return "SuperMarket";
        if(foodType.equals("CustomFood"))
            return "CustomFood";
        return "Null";
    }
}