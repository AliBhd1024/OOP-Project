import com.sun.source.tree.TryTree;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class RegistrationForm extends JDialog{
   private JPasswordField pfPassword;
    private JTextField registerTextField;
    private JTextField tfUsername;
    private JTextField Email;
    private JPasswordField pfConfirmPass;
    private JTextField PhoneNumber;
    private JTextField QuesNo;
    private JTextField Answer;
    private JButton cancelButton;
    private JButton registerButton;
    private JPanel registerPanel;

    public RegistrationForm(JFrame parent)
    {
        super (parent);
        setTitle("Hi welcome to SnapFood! Let's create an account!");
        setContentPane(registerPanel);
        setMinimumSize(new Dimension(450,474));
        setModal(true);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registerUser();
            }
        });
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        setVisible(true);
    }

    private void registerUser() {
        String username= tfUsername.getText();
        String pass=String.valueOf(pfPassword.getPassword());
        String confirmPass= String.valueOf(pfConfirmPass.getPassword());
        String email=Email.getText();
        String phone=PhoneNumber.getText();
        String securityNo=QuesNo.getText();
        String securityAns=Answer.getText();
        if(username.isEmpty())
        {
            JOptionPane.showMessageDialog(this,"Please enter your username!","Try again!",JOptionPane.ERROR_MESSAGE);
            return;
        } else if (pass.isEmpty()) {

            JOptionPane.showMessageDialog(this,"Please enter your password!","Try again!",JOptionPane.ERROR_MESSAGE);
            return;
        }
        else if(confirmPass.isEmpty())
        {
            JOptionPane.showMessageDialog(this,"Please enter your confirmation Password!","Try again!",JOptionPane.ERROR_MESSAGE);
            return;
        }
        else if(phone.isEmpty()){
            JOptionPane.showMessageDialog(this,"Please enter your phone number!","Try again!",JOptionPane.ERROR_MESSAGE);
            return;

        } else if (email.isEmpty()) {
            JOptionPane.showMessageDialog(this,"Please enter your email","Try again!",JOptionPane.ERROR_MESSAGE);
            return;
        }
        else if(securityAns.isEmpty()) {

            JOptionPane.showMessageDialog(this,"Please answer to your selected security question! ","Try again!",JOptionPane.ERROR_MESSAGE);
            return;
        } else if(securityNo.isEmpty())
        {
            JOptionPane.showMessageDialog(this,"Please select a security question to answer!","Try again!",JOptionPane.ERROR_MESSAGE);
            return;
        }
        if(!pass.equals(confirmPass))
        {
            JOptionPane.showMessageDialog(this,"Confirmation password does not match!","Try again!",JOptionPane.ERROR_MESSAGE);
            return;
        }
        user = addUsertoDatabase(username,email,phone,pass,securityAns,securityNo);

    }
    public User user;
    private User addUsertoDatabase(String username,String email,String phone,String password,String quesNo,String QuesAns)
    {
        User user=null;
        final String DB_URL="http://localhost/phpmyadmin/index.php?route=/database/sql&db=snapfood";
        final String USERNAME="root";
        final String PASSWORD="";
        try {
            Connection conn= DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
            Statement state= conn.createStatement();
            String sql="INSERT INTO users (username,email,phone,pass,securityAns,securityNo)"+"VALUES(?,?,?,?,?,?)";
            PreparedStatement preparedStatement=conn.prepareStatement(sql);
            preparedStatement.setString(1,username);
            preparedStatement.setString(2,email);
            preparedStatement.setString(3,phone);
            preparedStatement.setString(4,password);
            preparedStatement.setString(5,QuesAns);
            preparedStatement.setString(6,quesNo);

            int addedRows=preparedStatement.executeUpdate();
            if(addedRows>0)
            {
                user=new User();
                user.username=username;
                user.password=password;
                user.email=email;
                user.phone=phone;
                user.securityAns=QuesAns;
                user.securityNo=quesNo;
            }
            state.close();
            conn.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return user;
    }
    private void createUIComponents()
    {
        // TODO: place custom component creation code here
    }
    public static void main(String[] args) {
        RegistrationForm registrationForm=new RegistrationForm(null);
        User user=registrationForm.user;
        if(user!=null)
        {
            System.out.println("Dear"+user.username+"You have been registered successfully!");
        }
        else{
            System.out.println("Registration failed!");
        }
    }
}
